package com.gzu.homework_second;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/test")// 使用@WebServlet注解将此类声明为一个Servlet，并映射到"/test"路径
public class TestServlet extends HttpServlet {

    @Override

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {
            Thread.sleep(1000); // 1 second delay
        } catch (InterruptedException e) {// 如果线程被中断，重新设置中断状态
            Thread.currentThread().interrupt();
        }
        // 向客户端响应一条消息
        response.getWriter().println("Test Servlet - Request Logged Successfully!");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
