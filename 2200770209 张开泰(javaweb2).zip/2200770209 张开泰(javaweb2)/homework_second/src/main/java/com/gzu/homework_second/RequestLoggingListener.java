package com.gzu.homework_second;

import jakarta.servlet.ServletRequestEvent;
import jakarta.servlet.ServletRequestListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;
// 使用@WebListener注解将此类声明为一个监听器，监听Servlet请求事件
@WebListener
public class RequestLoggingListener implements ServletRequestListener {
    // 创建一个Logger实例用于日志记录
    private static final Logger LOGGER = Logger.getLogger(RequestLoggingListener.class.getName());
    // 创建一个日期格式化器，用于格式化日期时间字符串
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    // 当请求被初始化时调用此方法
    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        long startTime = System.currentTimeMillis();

        // 获取客户端IP地址、请求方法、请求URI和User-Agent头
        String clientIp = getClientIp(request);
        String method = request.getMethod();
        String requestUri = request.getRequestURI();
        String queryString = request.getQueryString();
        String userAgent = request.getHeader("User-Agent");

        StringBuilder logMessage = new StringBuilder();
        logMessage.append("Request Started - ")
                .append(dateFormat.format(new Date(startTime)))
                .append(" - Client IP: ").append(clientIp)
                .append(" - Method: ").append(method)
                .append(" - URI: ").append(requestUri);

        if (queryString != null) {
            logMessage.append("?").append(queryString);
        }

        logMessage.append(" - User-Agent: ").append(userAgent);

        LOGGER.info(logMessage.toString());

        // 将开始时间存储在请求属性中以便后续使用
        request.setAttribute("startTime", startTime);
    }

    // 当请求被销毁时调用此方法
    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        long startTime = (Long) request.getAttribute("startTime");
        long endTime = System.currentTimeMillis();
        long processingTime = endTime - startTime;

        // 记录请求处理时间
        String logMessage = "Request Completed - Processing Time: " + processingTime + "ms";
        LOGGER.info(logMessage);
    }

    // 获取客户端IP地址的辅助方法（考虑代理和负载均衡器的情况）
    private String getClientIp(HttpServletRequest request) {
        String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader == null) {
            return request.getRemoteAddr();
        }
        return xfHeader.split(",")[0];
    }
}
