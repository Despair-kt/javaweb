package com.gzu.homework1;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet(name = "LoginServlet", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 这里应该添加验证用户名和密码的逻辑
        // 例如，检查数据库中是否存在该用户名和密码
        // 为了简单起见，这里我们假设所有输入都是有效的

        // 如果验证成功，将用户信息存储在session中
        if (username != null && password != null) {
            request.getSession().setAttribute("user", username);
            response.sendRedirect(request.getContextPath() + "/");
        } else {
            // 验证失败，重定向回登录页面
            response.sendRedirect(request.getContextPath() + "/login?error");
        }
    }
}