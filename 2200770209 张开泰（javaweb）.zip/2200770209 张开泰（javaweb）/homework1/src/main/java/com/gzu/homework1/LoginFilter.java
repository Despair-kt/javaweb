package com.gzu.homework1;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@WebFilter("/*")
public class LoginFilter implements Filter {
    // 创建一个排除列表，包含不需要登录就能访问的路径
    private static final List<String> EXCLUDED_PATHS = Arrays.asList("/login", "/register", "/public");

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        String uri = request.getRequestURI();
        System.out.println(uri);

        // 检查当前请求路径是否在排除列表中
        boolean isExcluded = false;
        for (String path : EXCLUDED_PATHS) {
            if (uri.startsWith(path)) {
                isExcluded = true;
                break;
            }
        }

        if (isExcluded || uri.contains("login")) {
            // 如果在排除列表中或请求路径包含"login"，直接调用下一个过滤器或目标资源
            filterChain.doFilter(request, response);
        } else {
            // 如果不在排除列表中，检查用户是否已经登录
            HttpSession session = request.getSession();
            Object user = session.getAttribute("user");
            if (user != null) { // 用户已经登录
                filterChain.doFilter(request, response);
            } else { // 用户未登录，重定向到登录页面
                response.sendRedirect("/login.jsp");
            }
        }
    }
}